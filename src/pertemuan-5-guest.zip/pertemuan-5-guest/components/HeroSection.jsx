import React from "react";

const HeroSection = () => {
  return (
    <section className="relative w-full min-h-screen bg-[#f9f6f1] overflow-hidden px-6 md:px-16 py-10 flex flex-col justify-between">
      <div className="flex flex-col md:flex-row items-center justify-between w-full h-full">
        {/* Gambar kiri + alamat */}
        <div className="hidden md:flex w-1/3 flex-col gap-4">
          <img
            src="/img/barbershop.jpg"
            alt="Barbershop Icon"
            className="w-full max-w-xxl object-cover rounded-lg"
          />
          <div className="mt-25 text-sm text-gray-700">
            <h1 className="font-bold">Jl. Srikandi 08</h1>
            <p className="text-xs text-gray-500">Kecamatan Karangpawitan, Garut</p>
          </div>
        </div>

        {/* Konten utama */}
        <div className="z-10 relative -top-10 text-center md:text-left max-w-xl">
        <h1 className="text-4xl md:text-6xl font-serif font-bold text-gray-900 leading-tight mb-6">
          VAMOS Barbershop
          </h1>
          <p className="text-gray-700 text-base md:text-lg mb-10">
          Barbershop modern dengan gaya klasik — didirikan tahun 2024.
          Menggabungkan seni cukur rambut dengan nuansa elegan dan maskulin.
        </p>
        <button className="px-6 py-3 border border-black text-black rounded-full hover:bg-black hover:text-white transition">
          Explore
        </button>
      </div>
      <div className="hidden md:block w-1/3"> 
      <img
      
          src="/img/product.jpg"
          alt="Haircut Tools"
          className="mt-45 w-80 max-w-md object-cover rounded-lg"
        />
      </div>
      </div>
    </section>
  );
};

export default HeroSection;
